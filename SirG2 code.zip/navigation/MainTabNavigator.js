import React from 'react';
import {StyleSheet,Text,View,ScrollView,Image, } from 'react-native';
import {createDrawerNavigator,DrawerItems, SafeAreaView } from 'react-navigation';
import Icon  from 'react-native-vector-icons/MaterialCommunityIcons';
import FeatherIcon from 'react-native-vector-icons/Feather';

import HomeScreen from '../screens/HomeScreen';
import LecturesScreen from '../screens/LecturesScreen';
import AttendenceScreen from '../screens/AttendenceScreen';
import GradeScreen from '../screens/GradeScreen';
import HolidayScreen from '../screens/HolidatScreen';
import NoticeScreen from '../screens/NoticeScreen';
import NotesScreen from '../screens/NotesScreen';
import PaymentScreen from '../screens/PaymentScreen';

export default class MainTabNavigator extends React.Component{
  render(){
    return(
      <AppDrawerNavigator/>
    );
  }
}

const CustomDrawerContentComponent = (props) => (
  
	<SafeAreaView style={{flex:1}} forceInset={{ top: 'always', horizontal: 'never' }}>
		<View style={{height:150, backgroundColor:'#e4e3e3',alignItems:'center',justifyContent:'center'}}>
			<Image source={require('../assets/images/icon.png')} style={{height:120,width:120,borderRadius:60}}/>
		</View>
		
		<ScrollView>
			<DrawerItems {...props} />
		</ScrollView>
		
	</SafeAreaView>
  
);


const AppDrawerNavigator = createDrawerNavigator({
  Home:{
		screen:HomeScreen,
		navigationOptions: {
			drawerIcon: ({ tintColor }) => (<Icon name="home-outline" size={24} style={{ color: tintColor }} />),
	}
	},
	Lectures: {
		screen: LecturesScreen,
		navigationOptions: {
				drawerIcon: ({ tintColor }) => (<Icon name="theater" size={24} style={{ color: tintColor }} />),
		}
	},
	Notice: {
		screen: NoticeScreen,
		navigationOptions: {
				drawerIcon: ({ tintColor }) => (<Icon name="bell-outline" size={24} style={{ color: tintColor }} />),
		}
	},
	Attendance: {
		screen: AttendenceScreen,
		navigationOptions: {
				drawerIcon: ({ tintColor }) => (<Icon name="account-check" size={24} style={{ color: tintColor }} />),
		}
	},
	Grades: {
		screen: GradeScreen,
		navigationOptions: {
				drawerIcon: ({ tintColor }) => (<Icon name="format-annotation-plus" size={24} style={{ color: tintColor }} />),
		}
	},
	Notes: {
		screen: NotesScreen,
		navigationOptions: {
				drawerIcon: ({ tintColor }) => (<Icon name="file-pdf-box" size={24} style={{ color: tintColor }} />),
		}
	},
	Payment: {
		screen: PaymentScreen,
		navigationOptions: {
				drawerIcon: ({ tintColor }) => (<Icon name="currency-inr" size={24} style={{ color: tintColor }} />),
		}
	},
	Holiday: {
		screen: HolidayScreen,
		navigationOptions: {
				drawerIcon: ({ tintColor }) => (<Icon name="umbrella-outline" size={24} style={{ color: tintColor }} />),
		}
	}, 
},{
	contentComponent:CustomDrawerContentComponent,
})

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});